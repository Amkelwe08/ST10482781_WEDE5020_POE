/* js/main.js */
/* Interactivity: nav toggle, accordion, lightbox, portfolio search, form validation + AJAX, Leaflet map init */
document.addEventListener('DOMContentLoaded', function () {
  // small visual confirmation badge so you can see the script loaded without opening DevTools
  (function showLoadBadge(){
    try {
      const b = document.createElement('div');
      b.id = 'dev-load-badge';
      b.textContent = 'Main.js loaded';
      Object.assign(b.style, {
        position: 'fixed',
        right: '12px',
        bottom: '12px',
        background: '#03543f',
        color: '#fff',
        padding: '6px 10px',
        borderRadius: '6px',
        zIndex: 999999,
        fontSize: '12px',
        boxShadow: '0 2px 6px rgba(0,0,0,0.2)'
      });
      document.body.appendChild(b);
      setTimeout(() => b.remove(), 3000);
    } catch (e) { /* ignore if DOM not ready or other errors */ }
  })();
  // NAV toggle (mobile)
  const navToggle = document.querySelector('.nav-toggle');
  const navList = document.querySelector('nav ul');
  if (navToggle && navList) {
    navToggle.addEventListener('click', () => navList.classList.toggle('show'));
  }

  // ACCORDION
  document.querySelectorAll('.acc-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.closest('.accordion-item');
      const content = item.querySelector('.acc-content');
      const opened = content.style.display === 'block';
      // close all
      document.querySelectorAll('.acc-content').forEach(c => c.style.display = 'none');
      if (!opened) content.style.display = 'block';
    });
  });

  // LIGHTBOX
  const lightbox = document.getElementById('lightbox');
  if (lightbox) {
    document.querySelectorAll('.portfolio-item').forEach(item => {
      item.addEventListener('click', () => {
        const src = item.querySelector('img').getAttribute('src');
        lightbox.querySelector('img').setAttribute('src', src);
        lightbox.style.display = 'flex';
        document.body.style.overflow = 'hidden';
      });
    });
    lightbox.addEventListener('click', (e) => {
      if (e.target === lightbox) {
        lightbox.style.display = 'none';
        document.body.style.overflow = '';
      }
    });
  }

  // PORTFOLIO SEARCH FILTER
  const searchInput = document.getElementById('portfolio-search');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      const q = e.target.value.toLowerCase();
      document.querySelectorAll('.portfolio-item').forEach(item => {
        const text = (item.dataset.title || '') + ' ' + (item.dataset.tags || '');
        item.style.display = text.toLowerCase().includes(q) ? '' : 'none';
      });
    });
  }

  // Image entrance animations: mark key images as animatable and observe when they enter view
  (function setupImageAnimations(){
    try {
      const selector = '.service-item img, .portfolio-item img, .hero img, .logo';
      const els = Array.from(document.querySelectorAll(selector));
      if (!els.length) return;
      els.forEach(el => el.classList.add('animatable'));

      if ('IntersectionObserver' in window) {
        const obs = new IntersectionObserver((entries, o) => {
          entries.forEach(en => {
            if (en.isIntersecting) {
              en.target.classList.add('in-view');
              o.unobserve(en.target);
            }
          });
        }, { threshold: 0.2 });
        els.forEach(e => obs.observe(e));
      } else {
        // fallback: show all
        els.forEach(e => e.classList.add('in-view'));
      }
    } catch (e) { /* non-fatal */ }
  })();

  // FORM VALIDATION + AJAX SIMULATION
  function setupForm(selector, options = {}) {
    const form = document.querySelector(selector);
    if (!form) return;
    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      // clear previous errors
      form.querySelectorAll('.form-error').forEach(e => e.remove());
      const name = form.querySelector('[name="name"]');
      const email = form.querySelector('[name="email"]');
      const message = form.querySelector('[name="message"]');
      const phone = form.querySelector('[name="phone"]');
      let ok = true;
      if (name && !name.value.trim()) { showError(name, 'Please enter your name.'); ok = false; }
      if (email && !validateEmail(email.value)) { showError(email, 'Please enter a valid email.'); ok = false; }
      if (message && message.value.trim().length < 10) { showError(message, 'Message must be at least 10 characters.'); ok = false; }
  // simple gibberish check but allow common South African language words
  if (message && !isLikelyAcceptableMessage(message.value)) { showError(message, 'Please enter a clear message. We accept English, isiXhosa, isiZulu, Sesotho and Afrikaans.'); ok = false; }
      if (phone && phone.value.trim()) {
        // simple phone validation: digits, +, spaces
        if (!/^[\d+\s-()]{7,20}$/.test(phone.value.trim())) { showError(phone, 'Enter a valid phone number.'); ok = false; }
      }

      // Optional sessions field validation (removed) — kept here commented out for future reference
      // const sessionsEl = form.querySelector('#sessions');
      // if (sessionsEl) {
      //   const sessionsVal = parseInt(sessionsEl.value, 10);
      //   if (Number.isNaN(sessionsVal) || sessionsVal <= 0) {
      //     showError(sessionsEl, 'Please enter a valid number of sessions before submitting.');
      //     ok = false;
      //   }
      // }
      if (!ok) return;

      // show immediate toast notification
      showToast(options.successMessage || 'Thanks — your message has been sent.');

      // disable submit while "sending"
      const submit = form.querySelector('button[type="submit"], input[type="submit"]');
      if (submit) { submit.disabled = true; submit.dataset.orig = submit.textContent; submit.textContent = 'Sending...'; }

      // simulate server/AJAX (after which we reset form and re-enable submit)
      setTimeout(() => {
        if (submit) { submit.disabled = false; submit.textContent = submit.dataset.orig || 'Submit'; }
        form.reset();
      }, 900);
    });
  }

  // create a small accessible toast that appears immediately and auto-dismisses
  function showToast(message, opts = {}) {
    try {
      const t = document.createElement('div');
      t.className = 'site-toast site-toast--success';
      t.setAttribute('role', 'status');
      t.setAttribute('aria-live', 'polite');
      t.textContent = message;
      const close = document.createElement('button');
      close.className = 'toast-close';
      close.setAttribute('aria-label', 'Close notification');
      close.innerHTML = '✕';
      close.addEventListener('click', () => t.remove());
      t.appendChild(close);
      document.body.appendChild(t);
      // remove after 5s
      setTimeout(() => t.remove(), opts.duration || 5000);
    } catch (e) { /* ignore */ }
  }

  function showError(el, msg) {
    const d = document.createElement('div');
    d.className = 'form-error';
    d.setAttribute('role', 'alert');
    d.setAttribute('aria-live', 'assertive');
    d.textContent = msg;
    el.insertAdjacentElement('afterend', d);
    try {
      el.focus();
    } catch (e) {}
    try {
      d.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } catch (e) {}
  }

  function validateEmail(e) { return /\S+@\S+\.\S+/.test(e); }

  // Heuristic to avoid gibberish while allowing common words from local languages
  function isLikelyAcceptableMessage(text) {
    if (!text) return false;
    const s = text.trim();
    if (s.length < 10) return false; // too short (already checked elsewhere)

    // allow if text contains any common words from supported languages
    const common = ['sawubona','molo','enkosi','ngiyabonga','yebo','lumela','dankie','hallo','baie','kealeboha','ke a leboha','thank','thanks','please','asseblief'];
    const low = s.toLowerCase();
    for (const w of common) {
      if (low.includes(w)) return true;
    }

    // reject if too many repeated characters (aaaaaaa)
    if (/(.)\1{6,}/.test(s)) return false;

    // alphabetic density: letters vs total
    const letters = s.replace(/[^A-Za-zÀ-ž\u0100-\u024F]/g, '');
    if (letters.length / Math.max(1, s.length) < 0.5) return false;

    // require at least two words unless very long
    const words = s.split(/\s+/).filter(Boolean);
    if (words.length < 2 && s.length < 30) return false;

    // vowel density heuristic (most supported languages use vowels)
    const vowelMatch = letters.match(/[aeiouAEIOUáéíóúâêîôûãõäëïöüAEIOU]/g) || [];
    if (vowelMatch.length / Math.max(1, letters.length) < 0.09) return false;

    // not obviously gibberish
    return true;
  }

  // attach to forms
  setupForm('#enquiry-form', { successMessage: 'We got your message. We will get back to you shortly.' });
  setupForm('#contact-form', { successMessage: 'Your message was sent. We will contact you soon.' });

  // Leaflet map init if available
  if (typeof L !== 'undefined') {
    const mapEl = document.getElementById('map');
    if (mapEl) {
      const lat = -33.0153, lng = 27.9116; // approximate East London coords
      const map = L.map('map').setView([lat, lng], 13);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
      }).addTo(map);
      L.marker([lat, lng]).addTo(map).bindPopup('Asipiko Creative Agency (approx)').openPopup();
    }
  }
});
